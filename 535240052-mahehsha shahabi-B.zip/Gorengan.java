public class Gorengan extends jualan {
    private String nama;
            long harga;
            int kuantitas;

    public Gorengan(String nama, long harga, int kuantitas){
        super(nama, harga, kuantitas);
        this.kuantitas = kuantitas;
    }
    

    
}
